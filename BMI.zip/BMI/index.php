<?php
  error_reporting(0);
if ( isset($_POST['sbmit'])) {
  $t = $_POST['tinggi'];
  $b = $_POST['berat'];

  $h = 100;
  $l = 0.1;
  $p = 0.15;
  $bt = $t / 100;

  $lideal =  ($t - $h) - ($t - $h)*$l;
  $wideal = ($t - $h) - ($t - $h)*$p;
  $kal = $b /($bt * $bt) ;

  if ( $kal >= 18.5 && $kal <= 25 ){
    $hal = '<span class="bg-success">Berat Badan Normal</span>';
  }elseif ($kal > 25 && $kal < 30){
    $hal = '<span class="bg-warning">Berat Badan Gemuk</span>';
  }elseif ($kal > 30){
    $hal = '<span class="bg-danger">Berat Badan Obesitas</span>';
  }elseif ($kal < 18 ){
    $hal = '<span class="bg-primary">Berat Badan Kurus</span>';
  }else {
    $hal = 'ISI DULU!';
  }
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="assets/css/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
  <script src="assets/css/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="assets/js/jQuery/jquery.js"></script>
  <title>Calculator BMI</title>
  <style>
    .container .row .col-md-6 .card {
      background-color: rgb(0, 127, 134);
      border: none;
      box-shadow: 3px 2px 5px rgb(216, 216, 216);
    }

    .container .row .col-md-6 .card .card-body input{
      width: 90%;
      border: 0;
      border-radius: 5px;
      padding: 5px;  
    }

    #wanita {
      display: none;

    }
    /*Made With Love CSS3*/
.love {
display: inline-block;
position: relative;
top: .1.0em;
font-size: 0.9em;
color: #e74c3c;
-webkit-transform: scale(.9);
-moz-transform: scale(.9);
transform: scale(.9);
-webkit-animation: love .5s infinite linear alternate-reverse;
-moz-animation: love .5s infinite linear alternate-reverse;
animation: love .5s infinite linear alternate-reverse;
}
@-webkit-keyframes love {
to {-webkit-transform: scale(1.4);}
}
@-moz-keyframes love {
to {-moz-transform: scale(1.4);}
}
@keyframes love {
to {transform: scale(1.2);}
}
/*Made With Love CSS3*/
  </style>
</head>
<body>
  <h3 style="text-align:center; padding-top: 20px;">BeratBadanCek!</h3>
<br><br>
  <div class="container">
    <div class="row" data-aos="zoom-in-up">
      <div class="col-md-6">
          <div class="card card-shadow">
            <div class="card-body">
                <form action=""  method="post">
                    <span class="text-light"><b>Tinggi Badan :</b></span>
                    <div><input type="text" name="tinggi"><span class="text-light"><b> Cm</b></span></div><br><br>
                    <span class="text-light"><b>Berat Badan :</b></span>
                    <div><input type="text" name="berat"><span class="text-light"><b> Kg</b></span></div><br><br>
                    <button class="btn btn-success" name='sbmit' type="submit">Submit</button>
                  </form>
            </div>
    </div>
  </div>
  <div class="col-md-6">
      <div class="card card-shadow">
        <div class="card-body">
            <span><button id="Tpria"  style="background: #25291C;" class="btn btn-info" onclick="pria()">Pria</button></span>
            <span><button id="Twanita" style="background: #E6E49F;"  class="btn btn-info" onclick="wanita()">Wanita</button></span><br>
            <div id="pria">
                <?php echo '<b class="text-light"> Tinggi Badan Anda :</b> '. ' <b class="text-light"> '.$t.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Berat Badan Anda : </b>'. ' <b class="text-light"> '.$b.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Berat Badan Yang Ideal :</b>'. ' <b class="text-light"> '.$lideal.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Kalkulator BMI :</b>'. ' <b class="text-light"> '.$kal.'</b>'?><br>
                <?php echo '<b class="text-light"> '.$hal.'</b>'?>
            </div>
            <div id="wanita">
                <?php echo '<b class="text-light">Tinggi Badan Anda :</b>'. ' <b class="text-light"> '.$t.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Berat Badan Anda :</b> '. ' <b class="text-light"> '.$b.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Berat Badan Yang Ideal :</b>'. ' <b class="text-light"> '.$wideal.'</b>'?>
                <br><br>
                <?php echo '<b class="text-light">Kalkulator BMI :</b>'. ' <b class="text-light"> '.$kal.'</b>'?><br>
                <?php echo '<b class="text-light"> '.$hal.'</b>'?>
            </div>
        </div>
</div>
</div>
  </div>
  </div>
  <footer style="text-align: center; padding-top:40px;">
   <b>Script By</b> <a href="https://web.facebook.com/lampungprov.go.id" target="_blank"><span class="love">&#10084;</span>  Geraldine Firdaus</a>
  </footer>
  <script>
    function wanita(){
      $('#wanita').css('display', 'block')
      $('#pria').css('display', 'none')
      $('#Twanita').css('background-color','#25291C')
      $('#Tpria').css('background-color','#E6E49F')
    }
    function pria(){
      $('#Twanita').css('background-color','#E6E49F')
      $('#Tpria').css('background-color','#25291C')
      $('#pria').css('display', 'block')
      $('#wanita').css('display', 'none')
    }
    
  </script>
</body>
</html>
